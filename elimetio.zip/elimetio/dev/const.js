var STORING_MACHINES = [
		BlockID.elixir_collector,
		BlockID.elixir_storage
	]